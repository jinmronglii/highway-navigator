package com.highway.navigator;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
